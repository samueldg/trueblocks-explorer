#### Collections

• allow you to group together addresses for analysis,

• enable turning on or off multiple monitors at a time,

• allow you to export data and produce reports for more than one address at a time.

#### Related Links

- [Settings](/settings)
- [Support](/support)
