#### The dashboard...

• provides status information about the TrueBlocks system, and

• allows to you reorient yourself by returning to a known location.

#### Related Links

- [Settings](/settings)
- [Support](/support)
